<?php 

sleep(2);

echo "blabla";