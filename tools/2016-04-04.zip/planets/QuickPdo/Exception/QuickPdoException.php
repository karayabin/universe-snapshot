<?php

namespace QuickPdo\Exception;

/*
 * LingTalfi 2016-02-12
 */
class QuickPdoException extends \Exception {

}
