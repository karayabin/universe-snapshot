<?php

namespace BabyTree\Exception;

/*
 * LingTalfi 2015-12-20
 */
class BabyTreeException extends \Exception {

}
