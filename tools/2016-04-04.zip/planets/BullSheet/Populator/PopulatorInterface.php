<?php

namespace BullSheet\Populator;

/*
 * LingTalfi 2016-02-12
 */
interface PopulatorInterface
{
    /**
     * Populate some database.
     */
    public function populate();
}
