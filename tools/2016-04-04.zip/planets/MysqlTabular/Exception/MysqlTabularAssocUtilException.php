<?php

namespace MysqlTabular\Exception;

/*
 * LingTalfi 2015-10-03
 */
class MysqlTabularAssocUtilException extends \Exception{

}
