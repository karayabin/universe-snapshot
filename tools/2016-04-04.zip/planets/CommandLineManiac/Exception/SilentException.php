<?php

namespace CommandLineManiac\Exception;

/*
 * LingTalfi 2015-10-04
 */
class SilentException extends \Exception {

    /**
     *    this is some comments. fuck me! newline
     */
    
}
