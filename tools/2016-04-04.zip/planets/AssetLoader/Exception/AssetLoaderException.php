<?php

namespace AssetLoader\Exception;

/*
 * LingTalfi 2016-01-30
 */
class AssetLoaderException extends \Exception{

}
