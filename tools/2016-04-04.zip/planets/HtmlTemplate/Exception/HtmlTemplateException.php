<?php

namespace HtmlTemplate\Exception;

/*
 * LingTalfi 2016-02-29
 */
class HtmlTemplateException extends \Exception{

}
