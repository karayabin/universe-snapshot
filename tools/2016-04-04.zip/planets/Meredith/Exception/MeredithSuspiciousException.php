<?php

namespace Meredith\Exception;

use SuspiciousException\SuspiciousExceptionInterface;

/**
 * LingTalfi 2015-12-28
 */
class MeredithSuspiciousException extends MeredithException implements SuspiciousExceptionInterface
{

}