<?php

namespace Meredith\Exception;

/**
 * LingTalfi 2015-12-28
 */
class MeredithException extends \Exception
{

}