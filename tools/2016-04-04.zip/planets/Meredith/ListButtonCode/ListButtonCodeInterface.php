<?php

namespace Meredith\ListButtonCode;

/**
 * LingTalfi 2015-12-28
 *
 * Represents the js code of a datatable button (buttons extension of datatable plugin).
 *
 */
interface ListButtonCodeInterface
{
    public function render();
}