<?php

namespace Meredith\FormRenderer\ControlsRenderer;

/**
 * LingTalfi 2015-12-31
 */
interface ControlsRendererInterface
{
    public function render();
}