<?php

namespace Meredith\OnModalOpenAfter;
use Meredith\MainController\MainControllerInterface;

/**
 * LingTalfi 2015-12-31
 */
interface OnModalOpenAfterInterface
{


    public function render(MainControllerInterface $mc);
}