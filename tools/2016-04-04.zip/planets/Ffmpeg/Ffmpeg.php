<?php

namespace Ffmpeg;

/*
 * LingTalfi 2016-04-04
 */
class Ffmpeg
{


    public static $ffmpegPaths = ['/opt/local/bin/ffmpeg', "/usr/bin/ffmpeg"];
    public static $ffmpegPath = null;

    public static function getDurationInSeconds(string $file, string $ffmpegPath=null): int
    {
        $ffmpeg = self::getFfmpegPath($ffmpegPath);
        $duration = shell_exec("$ffmpeg -i \"" . self::dqEscape($file) . "\" 2>&1 | grep Duration | cut -f 4 -d ' '");
        a($duration);
        return 0;
    }


    //------------------------------------------------------------------------------/
    // 
    //------------------------------------------------------------------------------/
    private static function dqEscape(string $url):string
    {
        return str_replace('"', '\"', $url);
    }

    private static function getFfmpegPath(string $path = null): string
    {
        if (null !== $path) {
            return $path;
        }
        if (null === self::$ffmpegPath) {
            foreach (self::$ffmpegPaths as $path) {
                if (file_exists($path)) {
                    self::$ffmpegPath = $path;
                    break;
                }
            }
            if (null === self::$ffmpegPath) {
                throw new \Exception("No valid ffmpeg command found");
            }
        }
        return self::$ffmpegPath;
    }
}
