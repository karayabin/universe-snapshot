MimeTypeTool
=====================
2015-10-25



This class contains functions for handling mime type.



getMimeType
-----------
2015-10-25


```php
string        getMimeType ( string:file ) 
```


This method returns the mime type associated with the given file.
