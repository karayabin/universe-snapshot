Observer
============
2015-10-27



I'm an eye of the universe.
I observe patterns emerging while the universe is being created.




Articles
-------------

- [Planet Reference](https://github.com/lingtalfi/Observer/blob/master/article/article.planetReference.eng.md)