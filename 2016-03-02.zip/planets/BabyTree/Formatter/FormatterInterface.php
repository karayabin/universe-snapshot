<?php


namespace BabyTree\Formatter;


/**
 * FormatterInterface
 * @author Lingtalfi
 * 2015-12-25
 *
 */
interface FormatterInterface
{

    public function format(array $babyTreeInfo);
}
