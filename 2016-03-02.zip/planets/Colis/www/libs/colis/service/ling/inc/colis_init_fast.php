<?php


//------------------------------------------------------------------------------/
// COLIS LING - DEMO INIT - FAST VERSION
//------------------------------------------------------------------------------/
/**
 * In prod, you'll replace this file by your application config file of course...
 * bigbang is just a fast way to getting started.
 */
require_once "bigbang.php"; // start the local universe
require_once "demo.func.php";


define('WEB_ROOT_DIR', realpath(__DIR__ . "/../../../../../../www"));
define('YOUTUBE_API_KEY', "your API_KEY here..."); // use your youtube api key here
define('ITEMS_DIR_URL', '/uploads');





