<?php

namespace BullSheet\Generator;

/*
 * LingTalfi 2016-02-10
 */
interface BullSheetGeneratorInterface
{
    public function getPureData($domain = null);
}
