<?php

namespace BullSheet\Exception;

/*
 * LingTalfi 2016-02-10
 */
class BullSheetException extends \Exception {

}
