<?php  




sleep(3);

echo "echo '_BEAST_TEST_RESULTS:s=15;f=0;e=0;na=1;sk=2__';";