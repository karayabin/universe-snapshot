<?php

namespace Meredith\FormRenderer\ControlsRenderer\Control;

/**
 * LingTalfi 2015-12-31
 *
 */
interface TextareaControlInterface extends ControlInterface
{

}