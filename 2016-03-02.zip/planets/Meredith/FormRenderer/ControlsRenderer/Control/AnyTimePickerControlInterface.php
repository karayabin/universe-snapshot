<?php

namespace Meredith\FormRenderer\ControlsRenderer\Control;

/**
 * LingTalfi 2016-01-20
 */
interface AnyTimePickerControlInterface extends ControlInterface
{
    public function getPickerOptions();
}