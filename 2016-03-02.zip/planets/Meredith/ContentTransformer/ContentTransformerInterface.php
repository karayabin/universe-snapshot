<?php

namespace Meredith\ContentTransformer;

/**
 * LingTalfi 2015-12-29
 */
interface ContentTransformerInterface
{
    public function render($targetPos);
}