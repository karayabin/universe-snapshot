BumbleBee
=================
2015-10-25



- [BSR-0](https://github.com/lingtalfi/BumbleBee/blob/master/Autoload/convention.bsr0.eng.md): a class naming convention for php namespaces to ease autoloading
- [Butineur Autoloader](https://github.com/lingtalfi/BumbleBee/tree/master/Autoload): my implementation of BSR-0 autoloader
