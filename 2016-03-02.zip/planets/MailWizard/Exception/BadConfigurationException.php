<?php

namespace MailWizard\Exception;

/*
 * LingTalfi 2015-12-16
 */
class BadConfigurationException extends \Exception{

}
