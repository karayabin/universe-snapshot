QuickPdoExceptionTool
=================
2016-02-12





What is it?
-------------------


A helper to work with PDOException.
 




What are the new methods?
------------------------

- [isDuplicateEntry](https://github.com/lingtalfi/QuickPdo/blob/master/QuickPdoExceptionTool.md#isduplicateentry)
 
 
 
 

Methods
===========


isDuplicateEntry
-------------
2016-02-12


```php
bool        isDuplicateEntry ( \PDOException e )
```

Return whether or not the given pdo exception was caused by a duplicated entry.

