<?php

namespace PhpBeast\Exception;

/*
 * LingTalfi 2015-10-26
 */
class BeastTryLaterException extends \Exception{

}
