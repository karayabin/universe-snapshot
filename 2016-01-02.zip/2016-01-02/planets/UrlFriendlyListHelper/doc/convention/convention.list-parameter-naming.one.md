List parameter naming convention one 
=====================================
2015-11-02



This is the first convention about list parameter naming for the UrlFriendlyListHelper planet.
A convention is very important, it allows communication between components and the item generator.


This convention is named "one".



pagination
----------------

### one 

- widget parameters
----- page
- plugin parameters
----- nbItemsPerPage



sort
--------

### one

- widget parameters
----- sortId    # the sortId is "expanded" to a sort and a sens field
---------> sort
---------> sens 



search
----------

### one

- widget parameters
----- search  


