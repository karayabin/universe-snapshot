<?php

namespace UrlFriendlyListHelper\ItemGeneratorHelper;

/*
 * LingTalfi 2015-11-04
 * Indicates that the generator helper cuts the rows.
 * This is important for generator of type array,
 * because the nbTotalItems depends on the filtered rows.
 */
interface FilteringItemGeneratorHelperInterface 
{
}
