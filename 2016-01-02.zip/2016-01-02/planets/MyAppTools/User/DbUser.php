<?php

namespace MyAppTools\User;

/*
 * LingTalfi 2015-12-15
 */
class DbUser extends User
{

    public function getId()
    {
        return self::get('id', false);
    }


}
