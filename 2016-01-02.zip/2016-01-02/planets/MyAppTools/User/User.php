<?php

namespace MyAppTools\User;

/*
 * LingTalfi 2015-12-15
 */
class User
{
    protected static $userKey = "_myAppUser";


    public static function create(array $info)
    {
        self::startSession();
        $_SESSION[self::$userKey] = $info;
    }

    public static function destroy()
    {
        self::startSession();
        unset($_SESSION[self::$userKey]);
    }

    public static function isAlive()
    {
        self::startSession();
        return array_key_exists(self::$userKey, $_SESSION);
    }

    public static function get($key, $default = false)
    {
        self::startSession();
        if (array_key_exists($key, $_SESSION)) {
            return $_SESSION[$key];
        }
        return $default;
    }

    public static function getValue($key)
    {
        self::startSession();
        if (array_key_exists($key, $_SESSION)) {
            return $_SESSION[$key];
        }
        throw new \Exception("Unknown key: $key");
    }


    //------------------------------------------------------------------------------/
    // 
    //------------------------------------------------------------------------------/
    private static function startSession()
    {
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }
    }
}
