The Anarchist
============
2015-12-03


Hi, I'm a php developer; this is my blog.


In this blog, you'll find thoughts that I thought were worth sharing.


- [Venus](https://github.com/lingtalfi/TheAnarchist/blob/master/methodology/methodology.venus.eng.md), a methodology that I use sometimes to conceptualize some systems 


