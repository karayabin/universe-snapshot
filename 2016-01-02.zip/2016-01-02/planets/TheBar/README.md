The Bar
============
2015-11-03



Hi folks, welcome to the bar.
Listen to some of our customer's stories.


- [Joe's Corner](https://github.com/lingtalfi/TheBar/blob/master/joe/README.md): tells you about how the universe should be organized



