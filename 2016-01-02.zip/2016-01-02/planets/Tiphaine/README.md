Tiphaine
=============
2015-11-11




Tool for converting a string to a mixed value, using tiphaine notation.



It uses the [tiphaine notation](https://github.com/lingtalfi/Tiphaine/blob/master/notation.tiphaine.eng.md).

This tool might help you if you are creating your own notations, and for instance you create a notation 
where the word false actually means the boolean false.







History Log
------------------
    
- 1.0.0 -- 2015-11-11

    - initial commit
    
    





