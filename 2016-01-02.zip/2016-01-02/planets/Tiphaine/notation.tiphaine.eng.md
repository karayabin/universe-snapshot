Tiphaine notation
============
2015-11-11




Notation for variables of mixed types.


Tiphaine is a french first name and the french pronunciation for tiffn, which is the acronym for:

- t: true
- i: int
- f: float
- f: false
- n: null 



Tiphaine notation       |        Language signification
------------------      |   ------------------------
true                    |   true  (the boolean)
false                    |   false  (the boolean)
null                    |   null  (the special value null)
6                    |   6  (an int number)
6.4                    |   6.4  (a float number)




