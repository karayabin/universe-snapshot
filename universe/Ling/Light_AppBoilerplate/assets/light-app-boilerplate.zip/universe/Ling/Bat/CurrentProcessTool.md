CurrentProcessTool
=====================
2020-12-14 -> 2020-12-31



This class contains functions for helping with the current process.




isCli
-----------
2020-12-14


```php
isCli(): bool
```
Returns whether the current process is executed under cli.
     


