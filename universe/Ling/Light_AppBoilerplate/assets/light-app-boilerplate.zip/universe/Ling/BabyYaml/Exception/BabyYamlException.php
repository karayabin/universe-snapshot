<?php


namespace Ling\BabyYaml\Exception;

/**
 * The BabyYamlException class.
 */
class BabyYamlException extends \Exception
{

}