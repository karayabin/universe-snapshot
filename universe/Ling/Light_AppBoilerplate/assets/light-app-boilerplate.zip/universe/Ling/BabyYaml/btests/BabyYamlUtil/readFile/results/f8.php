<?php


$defs = [
    'doo' => "You don't need quotes, generally",
    'but' => 'true',
    'that' => 'quotes can escape otherwise special values like null, true, ...',
];