<?php


$defs = [
    'doo' => [
        'one' => 1,
        'two',
        'three' => [
            'poo' => 'zoo',
        ],
    ],
    [
        'doo',
        'foo',
    ],
];