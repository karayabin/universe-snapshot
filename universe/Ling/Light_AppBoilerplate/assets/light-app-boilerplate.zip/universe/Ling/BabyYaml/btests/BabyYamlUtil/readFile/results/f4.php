<?php


$defs = [
    'do:o' => 'soo',
    'foo',
];