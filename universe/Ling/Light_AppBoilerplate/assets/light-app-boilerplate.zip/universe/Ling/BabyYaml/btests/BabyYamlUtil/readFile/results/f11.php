<?php


$defs = [
    'doo' => null,
    'roo' =>
        'this is a multiline' . PHP_EOL .
        'this is a multiline'
    ,
    'joo' => 'eee',
];