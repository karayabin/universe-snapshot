<?php



namespace Ling\BabyYaml\Helper\WrappedString\Util\Exception;



/**
 * WrappedStringUtilException
 * @author Lingtalfi
 * 2015-03-07
 * 
 */
class WrappedStringUtilException extends \Exception{

}
