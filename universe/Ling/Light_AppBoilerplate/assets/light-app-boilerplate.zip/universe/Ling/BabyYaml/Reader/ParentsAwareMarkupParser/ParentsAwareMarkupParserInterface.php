<?php


namespace Ling\BabyYaml\Reader\ParentsAwareMarkupParser;



/**
 * ParentsAwareMarkupParserInterface
 * @author Lingtalfi
 * 2015-05-21
 * 
 */
interface ParentsAwareMarkupParserInterface {

    public function parse($string);
}
