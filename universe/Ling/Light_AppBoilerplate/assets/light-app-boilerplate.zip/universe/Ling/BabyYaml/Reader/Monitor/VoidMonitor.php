<?php


namespace Ling\BabyYaml\Reader\Monitor;


/**
 * VoidMonitor
 * @author Lingtalfi
 * 2015-05-13
 *
 */
class VoidMonitor implements MonitorInterface
{


    //------------------------------------------------------------------------------/
    // IMPLEMENTS MonitorInterface
    //------------------------------------------------------------------------------/
    public function say($msg, $tags = null)
    {
    }


}
