<?php


namespace Ling\BabyYaml\Helper\WrappedString\Util\Exception;



/**
 * WrappedStringUtilCircularException
 * @author Lingtalfi
 * 2015-03-07
 * 
 */
class WrappedStringUtilCircularException extends WrappedStringUtilException{

}
