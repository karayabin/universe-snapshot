<?php


$defs = [
    'doo' => 'soo',
    'foo',
];