[Back to the Ling/CyclicChainDetector api](https://github.com/lingtalfi/CyclicChainDetector/blob/master/doc/api/Ling/CyclicChainDetector.md)<br>
[Back to the Ling\CyclicChainDetector\Link class](https://github.com/lingtalfi/CyclicChainDetector/blob/master/doc/api/Ling/CyclicChainDetector/Link.md)


Link::getChild
================



Link::getChild — Returns the child of this instance.




Description
================


public [Link::getChild](https://github.com/lingtalfi/CyclicChainDetector/blob/master/doc/api/Ling/CyclicChainDetector/Link/getChild.md)() : [Link](https://github.com/lingtalfi/CyclicChainDetector/blob/master/doc/api/Ling/CyclicChainDetector/Link.md) | null




Returns the child of this instance.




Parameters
================

This method has no parameters.


Return values
================

Returns [Link](https://github.com/lingtalfi/CyclicChainDetector/blob/master/doc/api/Ling/CyclicChainDetector/Link.md) | null.








Source Code
===========
See the source code for method [Link::getChild](https://github.com/lingtalfi/CyclicChainDetector/blob/master/Link.php#L60-L63)


See Also
================

The [Link](https://github.com/lingtalfi/CyclicChainDetector/blob/master/doc/api/Ling/CyclicChainDetector/Link.md) class.

Previous method: [setChild](https://github.com/lingtalfi/CyclicChainDetector/blob/master/doc/api/Ling/CyclicChainDetector/Link/setChild.md)<br>Next method: [appendChildByEndNode](https://github.com/lingtalfi/CyclicChainDetector/blob/master/doc/api/Ling/CyclicChainDetector/Link/appendChildByEndNode.md)<br>

