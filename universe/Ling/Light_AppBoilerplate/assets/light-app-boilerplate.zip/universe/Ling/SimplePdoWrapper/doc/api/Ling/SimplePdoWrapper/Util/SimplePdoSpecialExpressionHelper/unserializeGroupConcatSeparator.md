[Back to the Ling/SimplePdoWrapper api](https://github.com/lingtalfi/SimplePdoWrapper/blob/master/doc/api/Ling/SimplePdoWrapper.md)<br>
[Back to the Ling\SimplePdoWrapper\Util\SimplePdoSpecialExpressionHelper class](https://github.com/lingtalfi/SimplePdoWrapper/blob/master/doc/api/Ling/SimplePdoWrapper/Util/SimplePdoSpecialExpressionHelper.md)


SimplePdoSpecialExpressionHelper::unserializeGroupConcatSeparator
================



SimplePdoSpecialExpressionHelper::unserializeGroupConcatSeparator — Returns the unserialized version of the given serialized string.




Description
================


public static [SimplePdoSpecialExpressionHelper::unserializeGroupConcatSeparator](https://github.com/lingtalfi/SimplePdoWrapper/blob/master/doc/api/Ling/SimplePdoWrapper/Util/SimplePdoSpecialExpressionHelper/unserializeGroupConcatSeparator.md)(string $serialized) : array




Returns the unserialized version of the given serialized string.




Parameters
================


- serialized

    


Return values
================

Returns array.








Source Code
===========
See the source code for method [SimplePdoSpecialExpressionHelper::unserializeGroupConcatSeparator](https://github.com/lingtalfi/SimplePdoWrapper/blob/master/Util/SimplePdoSpecialExpressionHelper.php#L24-L30)


See Also
================

The [SimplePdoSpecialExpressionHelper](https://github.com/lingtalfi/SimplePdoWrapper/blob/master/doc/api/Ling/SimplePdoWrapper/Util/SimplePdoSpecialExpressionHelper.md) class.



