<?php


namespace Ling\SimplePdoWrapper\Exception;


/**
 * The MysqlInfoUtilException class.
 *
 */
class MysqlInfoUtilException extends SimplePdoWrapperException
{
    
}