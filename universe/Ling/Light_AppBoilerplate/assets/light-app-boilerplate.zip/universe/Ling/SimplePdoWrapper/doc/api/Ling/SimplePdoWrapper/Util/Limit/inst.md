[Back to the Ling/SimplePdoWrapper api](https://github.com/lingtalfi/SimplePdoWrapper/blob/master/doc/api/Ling/SimplePdoWrapper.md)<br>
[Back to the Ling\SimplePdoWrapper\Util\Limit class](https://github.com/lingtalfi/SimplePdoWrapper/blob/master/doc/api/Ling/SimplePdoWrapper/Util/Limit.md)


Limit::inst
================



Limit::inst — Creates a new instance and returns it.




Description
================


public static [Limit::inst](https://github.com/lingtalfi/SimplePdoWrapper/blob/master/doc/api/Ling/SimplePdoWrapper/Util/Limit/inst.md)() : static




Creates a new instance and returns it.




Parameters
================

This method has no parameters.


Return values
================

Returns static.








Source Code
===========
See the source code for method [Limit::inst](https://github.com/lingtalfi/SimplePdoWrapper/blob/master/Util/Limit.php#L42-L45)


See Also
================

The [Limit](https://github.com/lingtalfi/SimplePdoWrapper/blob/master/doc/api/Ling/SimplePdoWrapper/Util/Limit.md) class.

Previous method: [__construct](https://github.com/lingtalfi/SimplePdoWrapper/blob/master/doc/api/Ling/SimplePdoWrapper/Util/Limit/__construct.md)<br>Next method: [set](https://github.com/lingtalfi/SimplePdoWrapper/blob/master/doc/api/Ling/SimplePdoWrapper/Util/Limit/set.md)<br>

