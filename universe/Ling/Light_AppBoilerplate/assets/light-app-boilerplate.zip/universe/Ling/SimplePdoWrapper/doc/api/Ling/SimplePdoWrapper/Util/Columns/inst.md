[Back to the Ling/SimplePdoWrapper api](https://github.com/lingtalfi/SimplePdoWrapper/blob/master/doc/api/Ling/SimplePdoWrapper.md)<br>
[Back to the Ling\SimplePdoWrapper\Util\Columns class](https://github.com/lingtalfi/SimplePdoWrapper/blob/master/doc/api/Ling/SimplePdoWrapper/Util/Columns.md)


Columns::inst
================



Columns::inst — Creates a new instance and returns it.




Description
================


public static [Columns::inst](https://github.com/lingtalfi/SimplePdoWrapper/blob/master/doc/api/Ling/SimplePdoWrapper/Util/Columns/inst.md)() : static




Creates a new instance and returns it.




Parameters
================

This method has no parameters.


Return values
================

Returns static.








Source Code
===========
See the source code for method [Columns::inst](https://github.com/lingtalfi/SimplePdoWrapper/blob/master/Util/Columns.php#L54-L57)


See Also
================

The [Columns](https://github.com/lingtalfi/SimplePdoWrapper/blob/master/doc/api/Ling/SimplePdoWrapper/Util/Columns.md) class.

Previous method: [__construct](https://github.com/lingtalfi/SimplePdoWrapper/blob/master/doc/api/Ling/SimplePdoWrapper/Util/Columns/__construct.md)<br>Next method: [set](https://github.com/lingtalfi/SimplePdoWrapper/blob/master/doc/api/Ling/SimplePdoWrapper/Util/Columns/set.md)<br>

