[Back to the Ling/SimplePdoWrapper api](https://github.com/lingtalfi/SimplePdoWrapper/blob/master/doc/api/Ling/SimplePdoWrapper.md)<br>
[Back to the Ling\SimplePdoWrapper\Util\Limit class](https://github.com/lingtalfi/SimplePdoWrapper/blob/master/doc/api/Ling/SimplePdoWrapper/Util/Limit.md)


Limit::getRowCount
================



Limit::getRowCount — Returns the rowCount of this instance.




Description
================


public [Limit::getRowCount](https://github.com/lingtalfi/SimplePdoWrapper/blob/master/doc/api/Ling/SimplePdoWrapper/Util/Limit/getRowCount.md)() : int




Returns the rowCount of this instance.




Parameters
================

This method has no parameters.


Return values
================

Returns int.








Source Code
===========
See the source code for method [Limit::getRowCount](https://github.com/lingtalfi/SimplePdoWrapper/blob/master/Util/Limit.php#L101-L104)


See Also
================

The [Limit](https://github.com/lingtalfi/SimplePdoWrapper/blob/master/doc/api/Ling/SimplePdoWrapper/Util/Limit.md) class.

Previous method: [getOffset](https://github.com/lingtalfi/SimplePdoWrapper/blob/master/doc/api/Ling/SimplePdoWrapper/Util/Limit/getOffset.md)<br>

