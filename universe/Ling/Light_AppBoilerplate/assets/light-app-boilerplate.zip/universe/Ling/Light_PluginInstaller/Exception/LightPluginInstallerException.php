<?php


namespace Ling\Light_PluginInstaller\Exception;

/**
 * The LightPluginInstallerException class.
 */
class LightPluginInstallerException extends \Exception
{

}