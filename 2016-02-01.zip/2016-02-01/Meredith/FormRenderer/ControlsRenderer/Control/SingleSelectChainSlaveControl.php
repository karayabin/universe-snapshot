<?php

namespace Meredith\FormRenderer\ControlsRenderer\Control;

/**
 * LingTalfi 2016-01-16
 *
 */
class SingleSelectChainSlaveControl extends SingleSelectControl implements SingleSelectChainSlaveControlInterface
{

}