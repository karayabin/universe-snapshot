<?php

namespace Meredith\FormRenderer\ControlsRenderer\Control;

/**
 * LingTalfi 2016-01-05
 *
 * A select with a single choice
 *
 */
interface SingleSelectControlInterface extends ControlInterface
{

    public function getValues2Labels();

}