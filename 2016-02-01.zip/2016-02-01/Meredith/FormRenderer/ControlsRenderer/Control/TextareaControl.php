<?php

namespace Meredith\FormRenderer\ControlsRenderer\Control;

/**
 * LingTalfi 2015-12-31
 *
 */
class TextareaControl extends Control implements TextareaControlInterface
{

}