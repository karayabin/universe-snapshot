<?php

namespace Meredith\ValidatorJsUserCode;

/**
 * LingTalfi 2015-12-29
 */
interface ValidatorJsUserCodeInterface
{

    public function render($section, $formId);
}