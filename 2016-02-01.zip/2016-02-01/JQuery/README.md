JQuery
=============
2015-11-03



Some compressed Jquery libraries.


Available libraries
-----------------------


- [2.1.4](https://github.com/lingtalfi/JQuery/releases/tag/2.1.4)
