Uri
=======
2015-12-04



This document defines some nomenclature about uri.




uri
------

In this document, an uri (uniform resource identifier) always start with a slash and is composed of two elements:

- baseUri
- queryString (optional), prepended by a question mark



baseUri
----------

The baseUri starts with a slash, and is the uri without its queryString part.


queryString
----------

The queryString is the part of the uri just after the first question mark found















