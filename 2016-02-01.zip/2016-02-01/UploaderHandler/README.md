UploaderHandler
=================
2016-01-12




A tool to help implementing an upload server (with or without chunking).



UploaderHandler can be installed as a [planet](https://github.com/lingtalfi/Observer/blob/master/article/article.planetReference.eng.md).










Dependencies
------------------

- [lingtalfi/Bat 1.27](https://github.com/lingtalfi/Bat)
- [lingtalfi/Tim 1.2.0](https://github.com/lingtalfi/Tim)






History Log
------------------
    
- 1.0.0 -- 2016-01-12

    - initial commit
    
    
