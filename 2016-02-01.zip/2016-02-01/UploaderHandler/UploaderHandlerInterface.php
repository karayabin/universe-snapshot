<?php

namespace UploaderHandler;

/*
 * LingTalfi 2016-01-11
 */
interface UploaderHandlerInterface
{


    /**
     * Might display things.
     * @return void
     */
    public function handle();
}
