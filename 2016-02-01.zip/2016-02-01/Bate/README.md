Bate
==========
2015-11-30





Bate (Basic Tools Extension) is an extension pack for [Bat](https://github.com/lingtalfi/Bat).





So far, the Bate library is composed of the following tools:



Tools       |       Description
----------- | -----------------------
[MicroStringTool]( https://github.com/lingtalfi/Bate/blob/master/MicroStringTool.md )          |       Tools for manipulating strings at the char level



Dependencies
------------------

- [lingtalfi/Bat 1.16](https://github.com/lingtalfi/Bat)



History Log
------------------
    
- 1.0.0 -- 2015-11-30

    - initial commit
    
    