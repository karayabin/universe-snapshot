RssUtil
===============
2015-10-23



RssUtil contains utilities related to rss.


- [RssWriter](https://github.com/lingtalfi/RssUtil/tree/master/RssWriter), an utility to create rss 2.0 feeds



Dependencies
------------------

- [MySimpleXmlElement 1.0.0](https://github.com/lingtalfi/MySimpleXmlElement)
