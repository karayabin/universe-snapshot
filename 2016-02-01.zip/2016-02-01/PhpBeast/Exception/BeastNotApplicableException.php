<?php

namespace PhpBeast\Exception;

/*
 * LingTalfi 2015-10-26
 */
class BeastNotApplicableException extends \Exception{

}
