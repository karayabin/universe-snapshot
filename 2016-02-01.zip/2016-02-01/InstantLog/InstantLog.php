<?php

namespace Universe;

/*
 * LingTalfi 2016-02-01
 */
class InstantLog
{

    /**
     * I recommend to add an alias in your .bashrc (otherwise you miss the "instant" point):
     *
     *      alias ilog='tail -f /tmp/instantlog.txt'
     *
     *
     */
    public static $file = "/tmp/instantlog.txt";


    public static function log($m)
    {
        file_put_contents(self::$file, $m . PHP_EOL, FILE_APPEND);
    }

}
