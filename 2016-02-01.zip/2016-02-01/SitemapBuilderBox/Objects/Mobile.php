<?php

namespace SitemapBuilderBox\Objects;

/*
 * LingTalfi 2015-10-10
 * https://support.google.com/webmasters/answer/6082207?hl=en
 */
class Mobile
{

    public static function create()
    {
        return new self;
    }
}
