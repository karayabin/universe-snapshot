<?php

namespace SitemapBuilderBox\Exception;

/*
 * LingTalfi 2015-10-07
 */
class SitemapBuilderException extends \Exception{

}
