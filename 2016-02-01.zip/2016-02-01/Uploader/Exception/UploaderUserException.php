<?php

namespace Uploader\Exception;

/*
 * LingTalfi 2016-01-06
 * An exception which message is intended for the gui (human) user
 */
class UploaderUserException extends \Exception
{

}
