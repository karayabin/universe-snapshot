The Scientist
==================
2015-10-14




- [portable Autoloader for php](https://github.com/lingtalfi/TheScientist/blob/master/convention.portableAutoloader.eng.md)
- [bee bash autoloader for php](https://github.com/lingtalfi/TheScientist/blob/master/convention.beeBashAutoloader.eng.md)





