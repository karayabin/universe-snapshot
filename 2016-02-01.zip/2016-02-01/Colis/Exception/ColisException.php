<?php

namespace Colis\Exception;

/*
 * LingTalfi 2016-01-12
 */
class ColisException extends \Exception{

}
