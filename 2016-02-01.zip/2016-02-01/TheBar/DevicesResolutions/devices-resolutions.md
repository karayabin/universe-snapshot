Devices Resolutions
======================
2016-01-22



These are based on google chrome dev tool.



Device Name               | Width   |  Height   |  is flippable
------------------------- | ------- | --------- | -------------- 
Amazon Kindle Fire HDX    |  1600   |   2560    |  yes
Apple IPad                |  768    |   1024    |  yes
Apple IPad Mini           |  768    |   1024    |  yes
Apple IPhone 4            |  320    |   480     |  yes
Apple IPhone 5            |  320    |   568     |  yes
Apple IPhone 6            |  375    |   627     |  yes
Apple IPhone 6 Plus       |  414    |   736     |  yes
BlackBerry PlayBook       |  600    |   1024    |  yes
BlackBerry Z30            |  360    |   640     |  yes
Google Nexus 4            |  384    |   567     |  yes
Google Nexus 5            |  360    |   567     |  yes
Google Nexus 6            |  412    |   659     |  yes
Google Nexus 7            |  600    |   960     |  yes
Google Nexus 10           |  800    |   1280    |  yes
LG Optimus L70            |  384    |   640     |  yes
Laptop with HiDPI screen  |  1440   |   900     |  no
Laptop with MDPI screen   |  1280   |   800     |  no
Laptop with touch         |  1280   |   950     |  no
Nokia Lumia 520           |  320    |   533     |  yes
Nokia N9                  |  320    |   640     |  yes
Samsung Galaxy Note 3     |  360    |   640     |  yes
Samsung Galaxy Note II    |  360    |   640     |  yes
Samsung Galaxy Note S III |  360    |   640     |  yes
Samsung Galaxy Note S4    |  360    |   640     |  yes
