<?php

namespace SuspiciousException;

/*
 * LingTalfi 2016-01-20
 * https://github.com/lingtalfi/ConventionGuy/blob/master/paradigm/paradigm.suspiciousException.eng.md
 * 
 */
interface SuspiciousExceptionInterface {

}
