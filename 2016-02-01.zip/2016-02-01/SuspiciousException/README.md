SuspiciousException
=======================
2016-01-20


This is an interface for the suspicious exception paradigm.




SuspiciousException can be installed as a [planet](https://github.com/lingtalfi/Observer/blob/master/article/article.planetReference.eng.md).


Details of the paradigm are explained in the [suspicious exception paradigm](https://github.com/lingtalfi/ConventionGuy/blob/master/paradigm/paradigm.suspiciousException.eng.md)




History Log
------------------
    
- 1.0.0 -- 2016-01-20

    - initial commit
    
    


