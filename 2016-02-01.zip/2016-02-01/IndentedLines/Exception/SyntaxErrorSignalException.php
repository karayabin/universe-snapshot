<?php

namespace IndentedLines\Exception;

/*
 * LingTalfi 2015-12-05
 */
class SyntaxErrorSignalException extends \Exception{

}
